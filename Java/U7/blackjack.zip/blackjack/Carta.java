package blackjack;
class Carta
{
    private String palo;
    private int valor;

    Carta(int valor, String palo)
    {
        this.valor = valor;
        this.palo = palo;
    }

    public int getvalor()
    {
        return this.valor;
    }

    public String getpalo()
    {
        return this.palo;
    }

    public String getcolor()
    {
        String color;
        if (this.palo == "pica" || this.palo  == "trebol")
        {
            color = "negro";
        }
        else
        {
            color = "rojo";
        }

        return color;
    }

    public void mostrar()
    {
        System.out.print(valor+" ");
        switch (palo)
        {
            case "pica" -> System.out.println("pica");
            case "corazon" -> System.out.println("corazon");
            case "trebol" -> System.out.println("trebol");
            case "diamante" -> System.out.println("diamante");
        }
    }
}
