public class BlackJack {
    public static void main(String[] args) {
        Baraja baraja1 = new Baraja(true, false);
        baraja1.mostrar();
    }
}
