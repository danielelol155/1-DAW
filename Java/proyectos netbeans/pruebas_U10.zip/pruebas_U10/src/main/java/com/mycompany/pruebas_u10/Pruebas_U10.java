/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pruebas_u10;

/**
 *
 * @author usuario
 */
public class Pruebas_U10 {

    public static void main(String[] args) {
        p3 p = new p3();
        p.setVisible(true);
    }
}
