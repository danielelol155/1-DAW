package blackjack;
import java.util.Arrays;

class Baraja
{
    private Carta barajajuego[];
    Baraja()
    {
        // sin 8 9 ni caballeros
        barajajuego = new Carta[44];
        int cont= 0;

        for (int j=1;j<8;j++)
        {
            Carta carta = new Carta(j, "pica");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=10;j<12;j++)
        {
            Carta carta = new Carta(j, "pica");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=13;j<15;j++)
        {
            Carta carta = new Carta(j, "pica");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=1;j<8;j++)
        {
            Carta carta = new Carta(j, "trebol");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=10;j<12;j++)
        {
            Carta carta = new Carta(j, "trebol");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=13;j<15;j++)
        {
            Carta carta = new Carta(j, "trebol");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=1;j<8;j++)
        {
            Carta carta = new Carta(j, "corazon");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=10;j<12;j++)
        {
            Carta carta = new Carta(j, "corazon");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=13;j<15;j++)
        {
            Carta carta = new Carta(j, "corazon");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=1;j<8;j++)
        {
            Carta carta = new Carta(j, "diamante");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=10;j<12;j++)
        {
            Carta carta = new Carta(j, "diamante");
            barajajuego [cont] = carta;
            cont++;
        }
        for (int j=13;j<15;j++)
        {
            Carta carta = new Carta(j, "diamante");
            barajajuego [cont] = carta;
            cont++;
        }
    }

    void addOchosYnueves()
    {
        int cont = this.barajajuego.length;
        barajajuego = Arrays.copyOf(barajajuego, barajajuego.length+8);
        for (int j=8;j<10;j++)
            {
                Carta carta = new Carta(j, "pica");
                barajajuego [cont] = carta;
                cont++;
            }
            for (int j=8;j<10;j++)
            {
                Carta carta = new Carta(j, "trebol");
                barajajuego [cont] = carta;
                cont++;
            }
            for (int j=8;j<10;j++)
            {
                Carta carta = new Carta(j, "corazon");
                barajajuego [cont] = carta;
                cont++;
            }
            for (int j=8;j<10;j++)
            {
                Carta carta = new Carta(j, "diamante");
                barajajuego [cont] = carta;
                cont++;
            }
    }

    void addCaballeros()
    {
        int cont = this.barajajuego.length;
        barajajuego = Arrays.copyOf(barajajuego, barajajuego.length+4);
            
            Carta carta = new Carta(12, "pica");
            barajajuego [cont] = carta;
            cont++;
        
            carta = new Carta(12, "trebol");
            barajajuego [cont] = carta;
            cont++;

            carta = new Carta(12, "corazon");
            barajajuego [cont] = carta;
            cont++;

            carta = new Carta(12, "diamante");
            barajajuego [cont] = carta;
            cont++;
        
    }
    
    Baraja(boolean ochoynueves, boolean caballeros)
    {
        this();
        
        if (ochoynueves)
        {
            this.addOchosYnueves();
        }
        if (caballeros)
        {
            this.addCaballeros();
        }
    }

    void mezclar()
    {
        Carta barajaCopia[] = barajajuego;
        int random = 0;
        int nums[] = new int [barajaCopia.length];
        int i=0;
        int cont = 0;

        while(i < barajajuego.length)
        {
            random = (int ) ( Math.random()* barajajuego.length);
            nums[i] = random;

            if (buscar(random, nums) == -1)
            {
                barajaCopia[cont] = barajajuego[random];
                cont++;
            }

            barajajuego = barajaCopia;
        }
    }

    void barajar()
    {
        this.mezclar();
    }


    public static int buscar(int valor, int tabla[])
    //busca un elemento en el array dado
    //si lo encuentra devuelve la posición del elemento
    //si no lo encuentra, devuelve -1
    {
        int encontrado = -1;

        for(int cont = 0; cont < tabla.length; cont++)
        {
            if(valor == tabla[cont])//encontrado
            {
                encontrado = cont;
                break;
            }
        }
        return encontrado;
    }

    public Carta robar()
    {
        this.mezclar();
        Carta temp = barajajuego[barajajuego.length-1];
        barajajuego = Arrays.copyOf(barajajuego, barajajuego.length-1);

        return temp;
    }

    public void reinicializar()
    {
        boolean ochoynueves;
        boolean caballeros;
        if (this.barajajuego.length == 44)
        {
            caballeros = false;
            ochoynueves = false;
        }
        else if (this.barajajuego.length == 48)
        {
            caballeros = true;
            ochoynueves = false;
        }
        else if (this.barajajuego.length == 52)
        {
            caballeros = false;
            ochoynueves = true;
        }
        else 
        {
            caballeros = true;
            ochoynueves = true;
        }
    }


    public void mostrar()
    {
        for (int i= 0;i<barajajuego.length;i++)
        {
            barajajuego[i].mostrar();
        }
    }
}